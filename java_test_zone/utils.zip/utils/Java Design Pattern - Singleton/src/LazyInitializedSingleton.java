public class LazyInitializedSingleton {

    private static LazyInitializedSingleton instance;
    
    private LazyInitializedSingleton(){}
    
    public static LazyInitializedSingleton getInstance(){
        if(instance == null){
            instance = new LazyInitializedSingleton();
            System.out.println("instance not exist - create a new instance");
        }
        else
        {
        	 System.out.println("instance exist - NO new instance");
        }
        return instance;
    }
}