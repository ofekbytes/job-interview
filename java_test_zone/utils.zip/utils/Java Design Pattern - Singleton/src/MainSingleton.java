//
// MainSingleton - 
//
public class MainSingleton {
	

	public MainSingleton() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//EagerInitializedSingleton
		System.out.println("==== EagerInitializedSingleton ====");
		EagerInitializedSingleton.getInstance();
		EagerInitializedSingleton.test();
		//System.out.println("EagerInitializedSingleton.getInstance() === " + EagerInitializedSingleton.getInstance());
		
		
		//StaticBlockSingleton
		System.out.println("==== StaticBlockSingleton ====");
		StaticBlockSingleton.getInstance();
		
		//LazyInitializedSingleton
		System.out.println("==== LazyInitializedSingleton ====");
		LazyInitializedSingleton.getInstance();
		//System.out.println();
	}

}
